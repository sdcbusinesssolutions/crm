const express = require('express');
const router = express.Router();
const { supabaseAdmin } = require('../../lib/supabaseClient');

// 1. Generate Auth URL
router.post('/auth-url', (req, res) => {
    try {
        const { clientId, redirectUrl } = req.body;

        const effectiveClientId = clientId || process.env.GOOGLE_CLIENT_ID;
        const effectiveRedirectUrl = redirectUrl || process.env.GOOGLE_REDIRECT_URL;

        if (!effectiveClientId || !effectiveRedirectUrl) {
            return res.status(400).json({ error: 'Missing Client ID or Redirect URL configuration' });
        }

        const { google } = require('googleapis');
        const oauth2Client = new google.auth.OAuth2(
            effectiveClientId,
            null,
            effectiveRedirectUrl
        );

        // Calendar Scopes
        const scopes = [
            'https://www.googleapis.com/auth/calendar',
            'https://www.googleapis.com/auth/calendar.events',
            'https://www.googleapis.com/auth/userinfo.email',
            'https://www.googleapis.com/auth/userinfo.profile'
        ];

        const url = oauth2Client.generateAuthUrl({
            access_type: 'offline', // Essential for refresh_token
            scope: scopes,
            prompt: 'consent' // Force refresh token generation
        });

        res.json({ url });
    } catch (error) {
        console.error('Calendar Auth URL Error:', error);
        res.status(500).json({ error: 'Failed to generate Auth URL' });
    }
});

// 2. Exchange Code
router.post('/exchange', async (req, res) => {
    try {
        const { code, clientId, clientSecret, redirectUrl, connectionName } = req.body;
        const userId = req.user.id;

        // Helper to sanitize inputs (remove quotes which cause "Invalid host defined options" and whitespace)
        // Aggressive clean: remove all whitespace, quotes, and non-printable chars
        const clean = (str) => (str || '').replace(/['"]/g, '').trim();

        // Use provided creds or fallback to env
        const creds = {
            clientId: clean(clientId || process.env.GOOGLE_CLIENT_ID),
            clientSecret: clean(clientSecret || process.env.GOOGLE_CLIENT_SECRET),
            redirectUrl: clean(redirectUrl || process.env.GOOGLE_REDIRECT_URL)
        };

        if (!code) return res.status(400).json({ error: 'Missing auth code' });
        if (!creds.clientId || !creds.clientSecret || !creds.redirectUrl) {
            return res.status(400).json({ error: 'Missing Google Client configuration (ID, Secret, or Redirect URL)' });
        }

        const { google } = require('googleapis');
        const oauth2Client = new google.auth.OAuth2(
            creds.clientId,
            creds.clientSecret,
            creds.redirectUrl
        );

        // A. Exchange
        console.log(`[Calendar Exchange] Exchanging code with Redirect URL: ${creds.redirectUrl}`);

        // DEBUG: Check for Proxy Environment Variables that might break gaxios
        const proxyVars = ['HTTP_PROXY', 'HTTPS_PROXY', 'http_proxy', 'https_proxy'];
        proxyVars.forEach(v => {
            if (process.env[v]) {
                console.warn(`[Calendar Exchange] Deleting detected proxy var: ${v}=${process.env[v]}`);
                delete process.env[v];
            }
        });

        // Ensure code is a clean string
        const cleanCode = String(code).trim();
        let tokens;

        try {
            const response = await oauth2Client.getToken(cleanCode);
            tokens = response.tokens;
        } catch (tokenError) {
            console.error('[Calendar Exchange] oauth2Client.getToken failed. Attempting Axios fallback...', tokenError.message);
            // FALLBACK: Manual Token Exchange via Axios
            try {
                const axios = require('axios');
                const tokenUrl = 'https://oauth2.googleapis.com/token';
                const payload = {
                    code: cleanCode,
                    client_id: creds.clientId,
                    client_secret: creds.clientSecret,
                    redirect_uri: creds.redirectUrl,
                    grant_type: 'authorization_code'
                };

                const { data } = await axios.post(tokenUrl, payload);
                tokens = data;
                console.log('[Calendar Exchange] Axios fallback SUCCESS!');
            } catch (axiosError) {
                console.error('[Calendar Exchange] Axios fallback FAILED:', axiosError.message);
                throw tokenError;
            }
        }

        oauth2Client.setCredentials(tokens);

        // B. Get User Info (Manual Axios Call - bypassing googleapis/gaxios completely)
        const axios = require('axios');
        console.log('[Calendar Exchange] Fetching User Info via Axios...');

        const userInfoResponse = await axios.get('https://www.googleapis.com/oauth2/v2/userinfo', {
            headers: { Authorization: `Bearer ${tokens.access_token}` }
        });

        const userInfoData = userInfoResponse.data;
        const email = userInfoData.email;
        console.log('[Calendar Exchange] User Info fetched successfully:', email);

        // Use user-provided name or default to email
        const finalConnectionName = connectionName || email;

        // C. Prepare Data to Save
        const storedCredentials = {
            ...tokens,
            params_client_id: clientId || null,
            params_client_secret: clientSecret || null,
            params_redirect_url: redirectUrl || null
        };

        // D. Upsert to DB with provider='google_calendar'
        const { data: existing } = await supabaseAdmin
            .from('user_integrations')
            .select('id')
            .eq('user_id', userId)
            .eq('provider', 'google_calendar')
            .eq('connection_name', finalConnectionName)
            .single();

        let result;
        if (existing) {
            result = await supabaseAdmin
                .from('user_integrations')
                .update({
                    credentials: storedCredentials,
                    metadata: userInfoData,
                    updated_at: new Date()
                })
                .eq('id', existing.id);
        } else {
            result = await supabaseAdmin
                .from('user_integrations')
                .insert({
                    user_id: userId,
                    provider: 'google_calendar',
                    connection_name: finalConnectionName,
                    credentials: storedCredentials,
                    metadata: userInfoData
                });
        }

        if (result.error) throw result.error;

        res.json({ success: true, name: finalConnectionName });

    } catch (error) {
        console.error('Calendar Exchange Error:', error);
        res.status(500).json({ error: error.message || 'Failed to exchange token' });
    }
});

// 2b. Save Service Account (Manual JSON)
router.post('/service-account', async (req, res) => {
    try {
        const { connectionName, credentials } = req.body;
        const userId = req.user.id;

        if (!connectionName || !credentials || !credentials.private_key || !credentials.client_email) {
            return res.status(400).json({ error: 'Invalid Service Account Data' });
        }

        const { data: existing } = await supabaseAdmin
            .from('user_integrations')
            .select('id')
            .eq('user_id', userId)
            .eq('provider', 'google_calendar')
            .eq('connection_name', connectionName)
            .single();

        let result;
        if (existing) {
            result = await supabaseAdmin
                .from('user_integrations')
                .update({
                    credentials,
                    metadata: { email: credentials.client_email, type: 'service_account' },
                    updated_at: new Date()
                })
                .eq('id', existing.id);
        } else {
            result = await supabaseAdmin
                .from('user_integrations')
                .insert({
                    user_id: userId,
                    provider: 'google_calendar',
                    connection_name: connectionName,
                    credentials,
                    metadata: { email: credentials.client_email, type: 'service_account' }
                });
        }

        if (result.error) throw result.error;

        res.json({ success: true });

    } catch (error) {
        console.error('Save Calendar Service Account Error:', error);
        res.status(500).json({ error: 'Failed to save Service Account' });
    }
});

// 3. List
router.get('/connections', async (req, res) => {
    try {
        const userId = req.user.id;
        const { data, error } = await supabaseAdmin
            .from('user_integrations')
            .select('id, connection_name, created_at, updated_at')
            .eq('user_id', userId)
            .eq('provider', 'google_calendar');

        if (error) throw error;
        res.json(data);
    } catch (error) {
        console.error('List Calendar Connections Error:', error);
        res.status(500).json({ error: 'Failed to list connections' });
    }
});

// 4. Delete
router.delete('/connections/:id', async (req, res) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;

        const { error } = await supabaseAdmin
            .from('user_integrations')
            .delete()
            .eq('id', id)
            .eq('user_id', userId);

        if (error) throw error;
        res.json({ success: true });
    } catch (error) {
        console.error('Delete Calendar Connection Error:', error);
        res.status(500).json({ error: 'Failed to delete connection' });
    }
});

module.exports = router;
