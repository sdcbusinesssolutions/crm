import React, { useState, useEffect, useLayoutEffect, useCallback } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { supabase } from './lib/supabase';

// Admin Pages
import AdminLogin from './pages/admin/auth/login';
import AdminDashboard from './pages/admin/dashboard/Dashboard';
import SuperDashboard from './pages/admin/SuperDashboard';
import AdminUsers from './pages/admin/users/Users';
import AdminPlans from './pages/admin/plans/Plans';
import AdminSubscriptions from './pages/admin/subscriptions/Subscriptions';
import AdminSettings from './pages/admin/settings/Settings';
import AdminLayout from './layouts/admin/AdminLayout';
import { Session } from '@supabase/supabase-js';
import Dashboard from './components/Dashboard';
import FlowEditor from './components/FlowEditor';
import Sidebar, { MenuItem } from './components/Sidebar';

import Contacts from './components/Contacts';
import InputFields from './components/InputFields';
import Inbox from './components/Inbox';
import GlobalSettings from './components/GlobalSettings';
import AuthPage from './components/AuthPage';
import { MenuIcon } from './components/icons';
import { themeService } from './services/themeService';
import FormPublicView from './components/FormPublicView';
import WhatsAppManagement from './components/WhatsAppManagement';
import AuthBridge from './components/WhatsAppManagement/AuthBridge';
import WhatsAppForms from './components/WhatsAppForms';
import WhatsAppFormBuilder from './components/WhatsAppFormBuilder';
import { tokenService } from './services/tokenService';
import TemplateList from './components/WhatsAppTemplates/TemplateList';
import TemplateBuilder from './components/WhatsAppTemplates/TemplateBuilder';
import CampaignList from './components/Campaigns/CampaignList';
import IntegrationsView from './components/Integrations/IntegrationsView';
import CampaignDetails from './components/Campaigns/CampaignDetails';
import FlowList from './components/FlowList';
import ImpersonationBanner from './components/ImpersonationBanner';
import MyPlan from './components/MyPlan';
import { ContactForms } from './components/ContactForms/ContactForms';
import ContactTags from './components/ContactTags';
import WhatsAppApiSettings from './components/WhatsAppApiSettings';
import CreateCampaignComponent from './components/Campaigns/CreateCampaign';
import { SheetAutomationList, SheetAutomationWizard } from './components/SheetAutomation';

import FormBuilder from './components/FormBuilder';
import GoogleCallbackPage from './components/GoogleCallbackPage';
import AuthCentralCallback from './components/AuthCentralCallback';
import AiVoiceAgentView from './components/AiVoiceAgent/AiVoiceAgentView';

const MainApp: React.FC = () => {
    // --- BOUNCE INTERCEPTOR (Master Domain Only) ---
    // Handles cross-domain impersonation redirects from Supabase Magic Links
    useLayoutEffect(() => {
        const params = new URLSearchParams(window.location.search);
        const bounceTarget = params.get('bounce');

        if (bounceTarget && window.location.hash.includes('access_token')) {
            console.log("Interceptor: Bouncing session to", bounceTarget);

            // Extract the hash from the current URL (Supabase put the tokens here)
            const hash = window.location.hash; // e.g., #access_token=...&refresh_token=...

            // Construct the final destination
            // Ensure target doesn't already have a hash mixed in weirdly, but usually it's clean base URL from backend
            let finalUrl = bounceTarget;

            // If target has query params, we append hash at the end
            // If target ends with slash, fine.

            // We strip the 'bounce' param from the current URL to keep history clean (optional), 
            // but we are redirecting anyway.

            // Redirect immediately
            window.location.href = `${finalUrl}${hash}`;
            return;
        }
    }, []);

    const [session, setSession] = useState<Session | null>(null);
    const [isAuthLoading, setIsAuthLoading] = useState(true);
    // State Initialization from URL Params (Persistence)
    const [activeMenuItem, setActiveMenuItem] = useState<MenuItem>(() => {
        const p = new URLSearchParams(window.location.search).get('view');
        return (p as MenuItem) || 'Dashboard';
    });
    const [currentFlowId, setCurrentFlowId] = useState<string | null>(() => new URLSearchParams(window.location.search).get('flowId'));
    const [currentWhatsAppFlowId, setCurrentWhatsAppFlowId] = useState<string | null>(() => new URLSearchParams(window.location.search).get('waFlowId'));
    const [currentTemplateId, setCurrentTemplateId] = useState<string | null>(() => new URLSearchParams(window.location.search).get('templateId'));
    const [isTemplateBuilderOpen, setIsTemplateBuilderOpen] = useState(() => new URLSearchParams(window.location.search).get('templateBuilder') === 'true');
    const [isCreatingCampaign, setIsCreatingCampaign] = useState(() => new URLSearchParams(window.location.search).get('createCampaign') === 'true');
    const [currentCampaignId, setCurrentCampaignId] = useState<string | null>(() => new URLSearchParams(window.location.search).get('campaignId'));
    const [currentPipelineId, setCurrentPipelineId] = useState<string | null>(() => new URLSearchParams(window.location.search).get('pipelineId'));
    const [isSidebarOpen, setSidebarOpen] = useState(false); // UI state, no need to persist
    const [isCreatingSheetAutomation, setIsCreatingSheetAutomation] = useState(() => new URLSearchParams(window.location.search).get('createSheetAuto') === 'true');
    const [editingSheetAutomationId, setEditingSheetAutomationId] = useState<string | null>(() => new URLSearchParams(window.location.search).get('editSheetAutoId'));
    const [createCampaignData, setCreateCampaignData] = useState<{
        templateId?: string;
        manualNumbers?: string[];
        title?: string;
    } | undefined>(undefined);

    // Domain Validation Logic (ROBUST & DEBUGGABLE)
    const validateDomain = async (currentSession: Session) => {
        if (!currentSession?.user) return;

        try {
            const { data: profile } = await supabase
                .from('profiles')
                .select('signup_domain, role')
                .eq('id', currentSession.user.id)
                .single();

            if (profile) {
                const rawAssigned = (profile as any).signup_domain || '';
                const rawCurrent = window.location.hostname || '';

                // Normalize: Lowercase, strip protocol (http/s), and strip 'www.'
                const checkNormalize = (d: string) => d.trim().toLowerCase()
                    .replace(/^https?:\/\//, '')
                    .replace(/^www\./, '');

                const assignedDomain = checkNormalize(rawAssigned);
                const currentDomain = checkNormalize(rawCurrent);

                const isLocalhost = currentDomain.includes('localhost') || currentDomain.includes('127.0.0.1');

                // Debug Logging for User/Dev (Visible in Browser Console)
                console.log(`[Tenancy Check] User: ${currentSession.user.email}`);
                console.log(`[Tenancy Check] Assigned: "${assignedDomain}" (Raw: "${rawAssigned}")`);
                console.log(`[Tenancy Check] Current:  "${currentDomain}" (Raw: "${rawCurrent}")`);

                // STRICT CHECK:
                if (assignedDomain && assignedDomain !== currentDomain && !isLocalhost) {
                    console.warn(`[Tenancy] Domain mismatch! Redirecting...`);

                    // Force Redirect
                    const protocol = window.location.protocol;
                    const cleanParams = new URLSearchParams(window.location.search);
                    cleanParams.set('email', currentSession.user.email || '');
                    cleanParams.set('redirect_reason', 'domain_mismatch');
                    cleanParams.set('expected', assignedDomain);
                    cleanParams.set('actual', currentDomain);

                    // CRITICAL: Preserve 'token' if present (Magic URL / Impersonation)
                    const magicToken = new URLSearchParams(window.location.search).get('token');
                    if (magicToken) {
                        cleanParams.set('token', magicToken);
                    }

                    const targetUrl = `${protocol}//${assignedDomain}/login?${cleanParams.toString()}`;

                    // Sign out from this wrong domain to clean up
                    await supabase.auth.signOut();

                    window.location.href = targetUrl;
                    return false; // Validation failed
                }
            } else {
                console.warn("[Tenancy Check] No profile found for user.");
            }
        } catch (e) {
            console.error("Domain validation error:", e);
        }
        return true; // Validation passed
    };

    // Check for existing session on load and handle redirects
    useEffect(() => {
        // Check if we are coming back from an auth redirect (email link)
        const isRedirecting = window.location.hash && (
            window.location.hash.includes('access_token') ||
            window.location.hash.includes('error_description')
        );

        if (isRedirecting) {
            console.log("Auth redirect detected, waiting for session processing...");
            setIsAuthLoading(true);
        }

        const checkSession = async () => {
            try {
                // getSession() will check local storage AND process the URL fragment if present
                const { data: { session }, error } = await supabase.auth.getSession();
                if (error) {
                    console.warn("Session check warning:", error.message);
                }
                if (session) {
                    // Validate Domain BEFORE setting session
                    const isValid = await validateDomain(session);
                    if (!isValid) return; // Stop loading if redirecting

                    setSession(session);
                    tokenService.setAccessToken(session.access_token);
                    // If we processed a hash, clean up the URL
                    if (window.location.hash) {
                        window.history.replaceState(null, '', ' ');
                    }
                }
            } catch (err) {
                console.error("Unexpected auth error:", err);
            } finally {
                // Always stop loading after initial check. 
                // onAuthStateChange will handle subsequent updates.
                setIsAuthLoading(false);
            }
        };

        checkSession();

        const {
            data: { subscription },
        } = supabase.auth.onAuthStateChange(async (event, session) => {
            console.log("Auth State Change:", event);

            // 1. Update State
            setSession(session);
            tokenService.setAccessToken(session?.access_token || null);

            // 2. Race Condition Handler:
            // If INITIAL_SESSION provides an expired (or nearly expired) token, 
            // DO NOT unlock the UI yet. Wait for the inevitable TOKEN_REFRESHED event.
            // This prevents API calls firing with dead tokens.
            const now = Math.floor(Date.now() / 1000);
            const isExpired = session?.expires_at && session.expires_at <= now;

            if (event === 'INITIAL_SESSION' && isExpired) {
                console.log("[Auth] Initial session expired. Waiting for refresh...");
                return; // Keep loading...
            }

            setIsAuthLoading(false);

            // 3. Perform Tenancy Check Asynchronously (Background)
            // We don't want to block the initial UI render or causing race conditions with AuthPage
            if (event === 'SIGNED_IN' && session) {
                // Small delay to allow local storage propogation if needed
                await new Promise(resolve => setTimeout(resolve, 100));

                // If validation fails, this will trigger a redirect/signout
                validateDomain(session).catch(e => console.error("Async Domain Validation Error:", e));
            }

            if (event === 'SIGNED_IN' && window.location.hash.includes('access_token')) {
                window.history.replaceState(null, '', ' ');
            }
        });

        // Safety fallback: If redirect handling hangs for 5s, force UI to render
        const safetyTimeout = setTimeout(() => {
            if (isAuthLoading) setIsAuthLoading(false);
        }, 5000);

        return () => {
            subscription.unsubscribe();
            clearTimeout(safetyTimeout);
        };
    }, []);

    // Apply theme on initial load
    useEffect(() => {
        if (!session) return;

        const loadTheme = async () => {
            const savedTheme = await themeService.getTheme();
            themeService.applyTheme(savedTheme);
        };
        loadTheme();
    }, [session]);

    // --- STATE PERSISTENCE EFFECT ---
    // Synchronize current state to URL Query Params
    useEffect(() => {
        if (isAuthLoading || !session) return;

        const params = new URLSearchParams(window.location.search);

        // View
        if (activeMenuItem && activeMenuItem !== 'Dashboard') params.set('view', activeMenuItem);
        else params.delete('view');

        // Flows
        if (currentFlowId) params.set('flowId', currentFlowId); else params.delete('flowId');
        if (currentWhatsAppFlowId) params.set('waFlowId', currentWhatsAppFlowId); else params.delete('waFlowId');

        // Templates
        if (currentTemplateId) params.set('templateId', currentTemplateId); else params.delete('templateId');
        if (isTemplateBuilderOpen) params.set('templateBuilder', 'true'); else params.delete('templateBuilder');

        // Campaigns
        if (currentCampaignId) params.set('campaignId', currentCampaignId); else params.delete('campaignId');
        if (isCreatingCampaign) params.set('createCampaign', 'true'); else params.delete('createCampaign');

        // Pipelines
        if (currentPipelineId) params.set('pipelineId', currentPipelineId); else params.delete('pipelineId');

        // Sheet Automation
        if (isCreatingSheetAutomation) params.set('createSheetAuto', 'true'); else params.delete('createSheetAuto');
        if (editingSheetAutomationId) params.set('editSheetAutoId', editingSheetAutomationId); else params.delete('editSheetAutoId');

        const newSearch = params.toString();
        const currentSearch = window.location.search.replace('?', '');

        // Only update if changed to avoid loops (though replaceState is cheap)
        if (newSearch !== currentSearch) {
            const newUrl = `${window.location.pathname}${newSearch ? '?' + newSearch : ''}${window.location.hash}`;
            window.history.replaceState(null, '', newUrl);
        }

    }, [
        activeMenuItem, currentFlowId, currentWhatsAppFlowId, currentTemplateId,
        isTemplateBuilderOpen, currentCampaignId, isCreatingCampaign,
        currentPipelineId, isCreatingSheetAutomation, editingSheetAutomationId,
        isAuthLoading, session
    ]);

    const handleNavigateToFlow = useCallback((flowId: string) => {
        setCurrentFlowId(flowId);
        setActiveMenuItem('Flows');
    }, []);

    const handleBackToDashboard = useCallback(() => {
        setCurrentFlowId(null);
        setActiveMenuItem('Flows');
    }, []);

    const handleMenuNavigation = useCallback((item: MenuItem) => {
        setActiveMenuItem(item);

        // Always reset flow view to list when clicking the main menu item
        if (item === 'Flows') {
            setCurrentFlowId(null);
        } else {
            setCurrentFlowId(null);
        }
        if (item !== 'Pipelines') {
            setCurrentPipelineId(null);
        }
        if (item !== 'Whatsapp Forms') {
            setCurrentWhatsAppFlowId(null);
        }
        if (item !== 'Whatsapp Templates') {
            setCurrentTemplateId(null);
            setIsTemplateBuilderOpen(false);
        }

        // Reset Campaign State
        if (item === 'Campaigns') {
            setIsCreatingCampaign(false);
            setCreateCampaignData(undefined);
            setCurrentCampaignId(null);
        } else {
            setIsCreatingCampaign(false);
            setCreateCampaignData(undefined);
            setCurrentCampaignId(null);
        }

        if (item !== 'Sheet Automation') {
            setIsCreatingSheetAutomation(false);
        }

        setSidebarOpen(false); // Close sidebar on mobile when navigating
    }, []);

    const handleLogout = useCallback(async () => {
        await supabase.auth.signOut();
        setSession(null);
        tokenService.clearAccessToken();
    }, []);

    const handleNavigateToWhatsAppBuilder = useCallback((flowId: string | null) => {
        setCurrentWhatsAppFlowId(flowId);
    }, []);

    const handleNavigateToPipeline = useCallback((pipelineId: string) => {
        setCurrentPipelineId(pipelineId);
        setActiveMenuItem('Pipelines');
    }, []);

    const handleBackToWhatsAppForms = useCallback(() => {
        setCurrentWhatsAppFlowId(null);
    }, []);

    const handleNavigateToTemplateBuilder = useCallback((templateId: string | null) => {
        setCurrentTemplateId(templateId);
        setIsTemplateBuilderOpen(true);
    }, []);

    const handleBackToTemplateList = useCallback(() => {
        setCurrentTemplateId(null);
        setIsTemplateBuilderOpen(false);
    }, []);

    // The current application logic (Dashboard + Flow Editor)
    const renderFlowBuilderApp = () => {
        if (currentFlowId) {
            return <FlowEditor flowId={currentFlowId} onBack={handleBackToDashboard} />;
        }
        return <FlowList onNavigateToFlow={handleNavigateToFlow} onToggleSidebar={() => setSidebarOpen(true)} />;
    };

    const renderContent = () => {
        // Prioritize Campaigns Check
        if (activeMenuItem === 'Campaigns') {
            if (currentCampaignId) {
                return (
                    <CampaignDetails
                        campaignId={currentCampaignId}
                        onBack={() => setCurrentCampaignId(null)}
                        onRetarget={(data) => {
                            setCreateCampaignData(data);
                            setIsCreatingCampaign(true);
                            setCurrentCampaignId(null);
                        }}
                    />
                );
            }
            if (isCreatingCampaign) {
                return (
                    <CreateCampaignComponent
                        onBack={() => {
                            setIsCreatingCampaign(false);
                            setCreateCampaignData(undefined);
                        }}
                        initialData={createCampaignData}
                    />
                );
            }
            return (
                <CampaignList
                    onCreate={() => {
                        setCreateCampaignData(undefined);
                        setIsCreatingCampaign(true);
                    }}
                    onSelect={(id) => setCurrentCampaignId(id)}
                    onToggleSidebar={() => setSidebarOpen(true)}
                />
            );
        }

        if (activeMenuItem === 'Dashboard') {
            return <Dashboard onNavigateToFlow={handleNavigateToFlow} onNavigate={handleMenuNavigation} onNavigateToPipeline={handleNavigateToPipeline} onToggleSidebar={() => setSidebarOpen(true)} />;
        }

        if (activeMenuItem === 'Flows') {
            return renderFlowBuilderApp();
        }

        if (activeMenuItem === 'Inbox') {
            return <Inbox onToggleSidebar={() => setSidebarOpen(true)} />;
        }



        if (activeMenuItem === 'Overview') {
            return <Contacts initialTab="dashboard" onToggleSidebar={() => setSidebarOpen(true)} />;
        }

        if (activeMenuItem === 'Contact List') {
            return <Contacts initialTab="contacts" onToggleSidebar={() => setSidebarOpen(true)} />;
        }

        if (activeMenuItem === 'Contacts') {
            return <Contacts initialTab="dashboard" onToggleSidebar={() => setSidebarOpen(true)} />;
        }

        if (activeMenuItem === 'Contact Groups') {
            return <Contacts initialTab="groups" onToggleSidebar={() => setSidebarOpen(true)} />;
        }

        if (activeMenuItem === 'Pipelines') {
            return <Contacts initialTab="pipelines" initialPipelineId={currentPipelineId} onToggleSidebar={() => setSidebarOpen(true)} />;
        }

        if (activeMenuItem === 'Follow-up') {
            return <Contacts initialTab="follow-up" onToggleSidebar={() => setSidebarOpen(true)} />;
        }

        if (activeMenuItem === 'Tags') {
            return <ContactTags />;
        }

        if (activeMenuItem === 'Input Fields') {
            return <Contacts initialTab="inputs" onToggleSidebar={() => setSidebarOpen(true)} />;
        }

        if (activeMenuItem === 'Form Contact') {
            return <ContactForms />;
        }

        if (activeMenuItem === 'Form Builder') {
            return <Contacts initialTab="forms" onToggleSidebar={() => setSidebarOpen(true)} />;
        }

        if (activeMenuItem === 'Settings' || activeMenuItem === 'Branding & Appearance') {
            return <GlobalSettings onToggleSidebar={() => setSidebarOpen(true)} />;
        }

        if (activeMenuItem === 'WhatsApp Management') {
            return <WhatsAppManagement />;
        }

        if (activeMenuItem === 'My Plan') {
            return <MyPlan />;
        }

        if (activeMenuItem === 'WhatsApp API') {
            return <WhatsAppApiSettings />;
        }

        if (activeMenuItem === 'Whatsapp Forms') {
            if (currentWhatsAppFlowId) {
                return <WhatsAppFormBuilder flowId={currentWhatsAppFlowId} onBack={handleBackToWhatsAppForms} />;
            }
            return <WhatsAppForms onNavigateToBuilder={handleNavigateToWhatsAppBuilder} />;
        }

        if (activeMenuItem === 'Whatsapp Templates') {
            if (isTemplateBuilderOpen) {
                return <TemplateBuilder templateId={currentTemplateId} onBack={handleBackToTemplateList} />;
            }
            return <TemplateList onNavigateToBuilder={handleNavigateToTemplateBuilder} />;
        }

        if (activeMenuItem === 'Integrations') {
            return <IntegrationsView onToggleSidebar={() => setSidebarOpen(true)} />;
        }

        if (activeMenuItem === 'AI Buddy') {
            return <AiVoiceAgentView />;
        }

        // ... (rest of code)
        // ...
        // Note: I will only replace the render logic and state initialization part if possible, 
        // or just the block where SheetAutomationWizard is rendered.

        // I need to be careful with line numbers.
        // Let's scroll down to SheetAutomation render block.

        if (activeMenuItem === 'Sheet Automation') {
            if (isCreatingSheetAutomation) {
                return (
                    <div className="p-4 md:p-8 h-full overflow-y-auto bg-slate-50 container-mobile-fix">
                        <div className="max-w-4xl mx-auto">
                            <button onClick={() => {
                                setIsCreatingSheetAutomation(false);
                                setEditingSheetAutomationId(null);
                            }} className="mb-4 text-slate-500 hover:text-slate-800 flex items-center gap-1 text-sm bg-white/50 p-2 rounded-lg lg:bg-transparent lg:p-0">
                                <span className="text-xl">←</span> Back to List
                            </button>
                            <SheetAutomationWizard
                                editId={editingSheetAutomationId || undefined}
                                onClose={() => {
                                    setIsCreatingSheetAutomation(false);
                                    setEditingSheetAutomationId(null);
                                }}
                                onSave={() => {
                                    setIsCreatingSheetAutomation(false);
                                    setEditingSheetAutomationId(null);
                                }}
                            />
                        </div>
                    </div>
                );
            }
            return (
                <div className="p-4 md:p-8 h-full overflow-y-auto bg-slate-50 container-mobile-fix">
                    <div className="max-w-6xl mx-auto">
                        <SheetAutomationList
                            onCreate={() => {
                                setEditingSheetAutomationId(null);
                                setIsCreatingSheetAutomation(true);
                            }}
                            onEdit={(id) => {
                                setEditingSheetAutomationId(id);
                                setIsCreatingSheetAutomation(true);
                            }}
                            onToggleSidebar={() => setSidebarOpen(true)}
                        />
                    </div>
                </div>
            );
        }

        return (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-500 h-full p-8 text-center animate-fade-in">
                <div className="w-20 h-20 bg-canvas-surface rounded-full shadow-sm flex items-center justify-center mb-6">
                    <span className="text-4xl">🛠️</span>
                </div>
                <h2 className="text-2xl font-bold mb-2 text-canvas-text">{activeMenuItem}</h2>
                <p className="max-w-md mx-auto text-slate-400">This module is currently under active development. Check back soon for updates.</p>
                <button
                    onClick={() => setActiveMenuItem('Flows')}
                    className="mt-8 px-6 py-2.5 bg-brand-600 text-white rounded-btn hover:bg-brand-700 transition-all shadow-lg shadow-brand-200 font-bold text-sm"
                >
                    Go to Flows
                </button>
            </div>
        );
    };

    // Handle Public Routes (Manual handling within MainApp if used directly, but usually handled by Router)
    // Legacy support if path was not caught by Router, though Router should handle it.
    // However, for clean separation, let's keep only auth logic here.

    if (isAuthLoading) {
        return (
            <div className="h-screen w-screen flex flex-col items-center justify-center bg-slate-50 text-brand-600">
                <div className="w-10 h-10 border-4 border-brand-200 border-t-brand-600 rounded-full animate-spin mb-4"></div>
                <p className="text-slate-500 text-sm font-medium animate-pulse">Verifying session...</p>
            </div>
        );
    }

    if (!session) {
        return <AuthPage />;
    }

    const isEditingFlow = activeMenuItem === 'Flows' && currentFlowId !== null;
    const isEditingWhatsAppFlow = activeMenuItem === 'Whatsapp Forms' && currentWhatsAppFlowId !== null;
    const isEditingTemplate = activeMenuItem === 'Whatsapp Templates' && isTemplateBuilderOpen;

    return (
        <div className="flex h-screen w-screen overflow-hidden">
            <ImpersonationBanner />
            <Sidebar
                activeItem={activeMenuItem}
                onNavigate={handleMenuNavigation}
                isOpen={isSidebarOpen}
                onClose={() => setSidebarOpen(false)}
                userEmail={session?.user?.email}
            />
            <div className="flex-1 flex flex-col overflow-hidden relative w-full min-h-0">
                {!isEditingFlow && !isEditingWhatsAppFlow && !isEditingTemplate &&
                    !['Inbox', 'Dashboard', 'Overview', 'Contacts', 'Contact List', 'Contact Groups', 'Pipelines', 'Flows', 'Campaigns', 'Sheet Automation', 'Settings', 'Branding & Appearance', 'Integrations', 'Follow-up', 'Input Fields', 'Form Builder'].map(s => s.toLowerCase()).includes((activeMenuItem || '').toLowerCase()) &&
                    (
                        <div className="lg:hidden flex items-center justify-between px-4 py-3 bg-canvas-surface border-b border-slate-200 z-20 shadow-sm shrink-0">
                            <div className="flex items-center space-x-3">
                                <button
                                    onClick={() => setSidebarOpen(true)}
                                    className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                                >
                                    <MenuIcon className="w-6 h-6" />
                                </button>
                                <div className="flex items-center space-x-2">
                                    <div className="w-6 h-6 bg-brand-600 rounded-md flex items-center justify-center">
                                        <span className="text-white font-bold text-xs">V</span>
                                    </div>
                                    <span className="font-bold text-lg text-slate-800">CRM</span>
                                </div>
                            </div>
                        </div>
                    )}
                {/* Logout Button (Temporary placement or accessible via Settings in real app) */}
                <div className="absolute top-3 right-4 z-50 hidden lg:block">
                    <button
                        onClick={handleLogout}
                        className="px-3 py-1.5 bg-white border border-slate-200 text-slate-600 text-xs font-bold rounded-lg hover:bg-slate-50 shadow-sm transition-colors"
                    >
                        Sign Out
                    </button>
                </div>

                {renderContent()}
            </div>
        </div>
    );
};

// Main Router Component
const App: React.FC = () => {
    return (
        <Router>
            <Routes>
                {/* Admin Routes */}
                <Route path="/admin" element={<Navigate to="/admin/auth/login" replace />} />
                <Route path="/admin/auth" element={<Navigate to="/admin/auth/login" replace />} />
                <Route path="/admin/auth/login" element={<AdminLogin />} />
                <Route path="/admin" element={<AdminLayout />}>
                    <Route path="dashboard" element={<AdminDashboard />} />
                    <Route path="users" element={<AdminUsers />} />
                    <Route path="plans" element={<AdminPlans />} />
                    <Route path="subscriptions" element={<AdminSubscriptions />} />
                    <Route path="settings" element={<AdminSettings />} />
                    <Route path="super" element={<SuperDashboard />} />
                </Route>

                {/* Public Form Route */}
                <Route path="/forms/:token" element={<FormPublicWrapper />} />

                {/* Google OAuth Callback */}
                <Route path="/rest/oauth2-credential/callback" element={<GoogleCallbackPage />} />

                {/* WhatsApp Central Auth Bridge */}
                <Route path="/waba_auth_bridge" element={<AuthBridge />} />

                {/* Generic Multi-Domain Auth Callback */}
                <Route path="/auth_callback" element={<AuthCentralCallback />} />

                {/* Main App Catch-All */}
                <Route path="/*" element={<MainApp />} />
            </Routes>
        </Router>
    );
};

// Wrapper for public form to extract params
const FormPublicWrapper = () => {
    // Using react-router hooks to get params
    // But since FormPublicView expects token as prop, we can just grab it from URL or use useParams
    // For now, let's reuse the logic inside MainApp if simpler, OR simpler:
    const path = window.location.pathname;
    const token = path.split('/forms/')[1];
    if (!token) return <div>Invalid Form Token</div>;
    return <FormPublicView token={token} />;
}

export default App;
